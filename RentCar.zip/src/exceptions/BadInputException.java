package exceptions;

public class BadInputException extends Exception {
    public BadInputException(final String message){ super(message); }
}
