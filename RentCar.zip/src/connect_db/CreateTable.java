package connect_db;

import java.sql.Connection;
import java.sql.Statement;

public class CreateTable {

    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;

        ConnectDB obj_ConnectDB = new ConnectDB();
        connection = obj_ConnectDB.get_Connection();

        try {
            String query = "create table bdd1.employee(sl_no SERIAL primary key, name varchar(200), address varchar(200))";
            statement = connection.createStatement();
            statement.executeUpdate(query);
            System.out.println("Query executed successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
