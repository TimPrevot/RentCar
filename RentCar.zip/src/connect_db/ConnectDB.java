package connect_db;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectDB {

    public static void main(String[] args) {
        ConnectDB obj_ConnectDB = new ConnectDB();
        System.out.println(obj_ConnectDB.get_Connection());
    }

    public Connection get_Connection() {

        Connection connection = null;

        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/RentCar_FX", "postgres", "abcd1234");

            if (connection != null){
                System.out.println("Connection established !");
            } else {
                System.out.println("Connection failed");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return connection;
    }
}

